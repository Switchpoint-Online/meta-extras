module.exports = function (RED) {
  const client = require('../lib/hikvision-api-client');

  function HikcentralConfig(n) {
    RED.nodes.createNode(this, n);
    this.name = n.name;
    this.ip = n.ip;
    this.port = Number(n.port || 443);
    this.insecureTls = !!n.insecureTls;

    const creds = this.credentials || {};
    this.ak = creds.ak;
    this.sk = creds.sk;
  }

  RED.nodes.registerType('hikcentral-config', HikcentralConfig, {
    credentials: {
      ak: { type: 'text' },
      sk: { type: 'password' }
    }
  });

  function HikcentralCallNode(config) {
    RED.nodes.createNode(this, config);
    const node = this;

    node.cfg = RED.nodes.getNode(config.config);
    node.uriProp = config.uri || "";

    if (!node.cfg || !node.cfg.ip || !node.cfg.ak || !node.cfg.sk) {
      node.status({ fill: 'red', shape: 'ring', text: 'missing config' });
    }

    node.on('input', async (msg, send, done) => {
      const uri = (node.uriProp && node.uriProp.trim()) ? node.uriProp.trim() : String(msg.uri || '');
      const body = msg.payload;

      if (!uri) {
        const err = new Error('URI path is required (set node "URI path" or msg.uri).');
        node.status({ fill: 'red', shape: 'ring', text: 'no uri' });
        if (done) return done(err);
        node.error(err, msg);
        return;
      }

      try {
        const base = `https://${node.cfg.ip}:${node.cfg.port}`;
        const res = await client.callHikvisionAPI({
          baseURL: base,
          ak: node.cfg.ak,
          sk: node.cfg.sk,
          insecureTls: !!node.cfg.insecureTls,
          method: 'POST',
          uriPath: uri,
          body
        });

        msg.statusCode = res.status;
        msg.payload = res.data;
        msg.request = {
          url: `${base}${uri}`,
          method: 'POST',
          headers: res.requestHeaders
        };

        node.status({ fill: 'green', shape: 'dot', text: String(res.status) });
        send(msg);
        if (done) done();
      } catch (e) {
        node.status({ fill: 'red', shape: 'dot', text: 'error' });
        if (done) done(e);
        else node.error(e, msg);
      }
    });
  }

  RED.nodes.registerType('hikcentral-call', HikcentralCallNode);
};
