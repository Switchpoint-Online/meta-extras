password DQ*'5HZ-TMAq5UD4
AK 21830011
SK LnHugQEbXLkUJstdyIBY
# HIKVISION CENTRAL PRO
## Install main package and openAPI 
### in web client config
go to system enable openAPI
ensure all access systems are created
ie. access groups, personal, custom field under additional information is set to public and 
### Create openAPI user and Authorize

#### PS Scripts
Get person list 
```
node app.js /artemis/api/resource/v1/person/advance/personList '{"pageNo":1,"pageSize":2}'
```
Get Person Info by ID
```
node app.js /artemis/api/resource/v1/person/personId/personInfo '{"personId":\"1\","appendInfo":[6]}'
```

Get access groups
```
node app.js /artemis/api/acs/v1/privilege/group '{"pageNo":1,"pageSize":2,"type":1}'
```

Add Group to person by personId ( NOT CODE )
```
node app.js /artemis/api/acs/v1/privilege/group/single/addPersons '{"privilegeGroupId":"1","type":1,"list":[{"id":"1"}]}'
```

Remove Access from personID
```
node app.js /artemis/api/acs/v1/privilege/group/single/deletePersons '{"privilegeGroupId":"1","type":1,"list":[{"id":"1"}]}'
```

edit customField for person 1
```
node app.js /artemis/api/resource/v1/person/personId/customFieldsUpdate '{\"personId\":\"1\",\"list\":[{\"id\":\"5\",\"customFiledName\":\"podScanId\",\"customFieldType\":0,\"customFieldValue\":\"\"}]}'
```

### Event suscription
```
node app.js /artemis/api/eventService/v1/eventSubscriptionByEventTypes '{\"eventTypes\":[197127],\"eventDest\":\"http://192.168.0.25:80/hikProAPI\",\"token\":\"qscasd\",\"passBack\":1}'
```