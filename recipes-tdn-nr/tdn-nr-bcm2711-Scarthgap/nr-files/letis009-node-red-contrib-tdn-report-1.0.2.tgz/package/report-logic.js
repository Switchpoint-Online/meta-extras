module.exports = function(msg, RED, node) {
    const globalContext = node.context().global;

    const reportType = msg.type || globalContext.get("prod.reportFormat") || "SBV+Rej";
    const enabledDevice = msg.enabledDevice || globalContext.get("prod.enabledDevice") || "ANALOGUE";

    /* Full report logic from user’s function goes here */
    let counters = msg?.payload?.BPS?.Machine?.[0]?.ParameterSection?.[0]?.HeadercardUnit?.[0]?.Counter;
    const envelope = msg?.payload?.Envelope?.MACHINE?.[0]?.HCUNIT?.[0]?.COUNTER;

    if (!counters) {
        counters = msg.payload.Envelope?.MACHINE?.[0]?.HCUNIT?.[0]?.COUNTER
        if (!envelope) {
            return null;
        }
    }

    const machine = msg.payload?.BPS?.Machine?.[0] ?? msg.payload?.Envelope?.MACHINE?.[0];

    const headerUnit = machine.ParameterSection?.[0]?.HeadercardUnit?.[0] ?? machine?.HCUNIT?.[0];

    const counterType = machine?.$?.Type ?? machine?.$?.type ?? ("")
    let operatorName = ""
    let headCardUnit = ""
    if (counterType.toUpperCase() === "BPS M5" || counterType.toUpperCase() === "BPS M7"){
        operatorName = machine.USER[0]?.$?.name ?? ("");
        headCardUnit = headerUnit?.$?.headercardid ?? ("")
    }

    const defaultCurrency = headerUnit?.$?.Currency || 'ZAR';
    const serial= machine.$.SerialNumber ?? machine.$.serialnumber;
    const printTime = msg.payload.BPS?.$.Created || '' ;
    const startTime = machine.ParameterSection?.[0].HeadercardUnit[0].$.StartTime ?? `${machine.PARSECT[0].$.startdate} ${machine.PARSECT[0].$.starttime}`;
    const endTime = machine.ParameterSection?.[0].HeadercardUnit[0].$.EndTime ?? `${machine.PARSECT[0].$.enddate} ${machine.PARSECT[0].$.endtime}`

    const operatorID = machine.ParameterSection?.[0]?.Operator[0] ?? machine.USER[0].$.userid

    const opMode = 
        (machine?.ParameterSection && machine.ParameterSection[0]?.$?.opmodename)
        ?? (machine?.PARSECT && machine.PARSECT[0]?.$?.sortingmode)
        ?? ("");

    const depositID = machine.ParameterSection?.[0].HeadercardUnit[0].$.DepositID || ''
    const declaredAmount = machine.ParameterSection?.[0].HeadercardUnit[0].$.DeclaredDepositAmount ?? machine.HCUNIT[0].$.dTotalAmount

    const printStringArray = [];

    let totalQuantity = 0;
    let totalAmount = 0;
    let rejectTotal = 0;
    let rejectValue = 0;
    let fitTotal = 0;
    let fitValue = 0;

    let maxLinechar = 40;

    const reportFormat = (reportType || '').toString().toUpperCase();
    switch (reportFormat) {
        case "1": {
            printStringArray.push('-'.repeat(maxLinechar));
            printStringArray.push(centerLine('DEPOSIT REPORT'));
            printStringArray.push(formatLine('MACHINE ID', serial));
            printStringArray.push(formatLine('MACHINE SN', serial));
            printStringArray.push(formatLine('PRINT TIME', printTime));
            printStringArray.push(formatLine('BEGIN', startTime));
            printStringArray.push(formatLine('END', endTime));
            printStringArray.push(formatLine('OPERATOR ID', operatorID));
            printStringArray.push(formatLine('MODE', opMode));
            printStringArray.push('-'.repeat(maxLinechar));
            printStringArray.push(formatLine('CURRENCY', defaultCurrency));
            printStringArray.push('QUAL'.padEnd(8) +
                'DENOM'.padEnd(8) +
                'NUMB#'.padStart(12) +
                'AMOUNT'.padStart(12));

            const grouped = {};

            for (const denomination of counters) {
                const currency = defaultCurrency;
                const value = Number(denomination.$.Value ?? denomination.$.value);
                const quality = denomination.$.Quality?.trim() ?? denomination.$.quality;
                const number = Number(denomination.$.Number ?? denomination.$.number);
                const amount = value * number;

                const key = `${currency}_${value}_${quality}`;

                if (!grouped[key]) {
                    grouped[key] = {
                        currency,
                        value,
                        quality,
                        number: 0,
                        amount: 0
                    };
                }

                grouped[key].number += number;
                grouped[key].amount += amount;

                totalQuantity += number;
                totalAmount += amount;

                if (quality.toUpperCase() !== "REJECT") {
                    fitTotal += number;
                    fitValue += amount;
                }

                if (/^REJECT$/i.test(quality)) {
                    rejectTotal += number;
                    rejectValue += amount;
                }
            }

            const sorted = Object.values(grouped).sort((a, b) => a.value - b.value);

            for (const item of sorted) {
                if (item.quality.toUpperCase() !== "REJECT") {
                    const qual = item.quality.padEnd(8);
                    const denom = `${item.currency}_${item.value}`.padEnd(8);
                    const num = item.number.toString().padStart(12);
                    const amt = item.amount.toString().padStart(12);
                    const line = (qual + denom + num + amt).substring(0, maxLinechar);
                    printStringArray.push(line);
                }
            }

            printStringArray.push(' '.repeat(maxLinechar / 2) + '-'.repeat(maxLinechar / 2));
            printStringArray.push(fitTotal.toString().padStart(28) +
                fitValue.toString().padStart(12)
            );

            printStringArray.push('REJECTS'.padEnd(maxLinechar));
            for (const item of sorted) {
                if (item.quality.toUpperCase() === "REJECT") {
                    const qual = ' '.padEnd(8);
                    const denom = `${item.currency}_${item.value}`.padEnd(8);
                    const num = item.number.toString().padStart(12);
                    const amt = item.amount.toString().padStart(12);
                    const line = (qual + denom + num + amt).substring(0, maxLinechar);
                    printStringArray.push(line);
                }
            }

            printStringArray.push(' '.repeat(20) + '-'.repeat(20));
            printStringArray.push(rejectTotal.toString().padStart(28) +
                rejectValue.toString().padStart(12)
            );

            printStringArray.push(' '.repeat(maxLinechar / 2) + '-'.repeat(maxLinechar / 2));
            printStringArray.push('Total'.padEnd(16) + totalQuantity.toString().padStart(12) + totalAmount.toString().padStart(12));
            printStringArray.push('-'.repeat(maxLinechar));
            break;
        }

        case "2": {
            printStringArray.push('-'.repeat(maxLinechar));
            printStringArray.push(centerLine('DEPOSIT REPORT'));
            printStringArray.push(formatLine('CURRENCY', defaultCurrency));
            printStringArray.push('QUAL'.padEnd(8) +
                'DENOM'.padEnd(8) +
                'NUMB#'.padStart(12) +
                'AMOUNT'.padStart(12));
            var denominationMap = {};
            for (const denomination of counters) {
                const value = denomination.$.Value ?? denomination.$.value;
                const number = Number(denomination.$.Number ?? denomination.$.number);
                if (!denominationMap[value]) {
                    denominationMap[value] = {
                        Currency: defaultCurrency,
                        Value: Number(denomination.$.Value ?? denomination.$.value),
                        Number: 0
                    };
                }
                denominationMap[value].Number += number;
            }
            for (const key in denominationMap) {
                const denom = denominationMap[key];
                const subtotal = denom.Value * denom.Number;

                totalAmount += subtotal;
                totalQuantity += denom.Number;

                const line = ("FIT".padEnd(8) +
                    `${defaultCurrency}_${denom.Value.toString()}`.padEnd(8) +
                    (denom.Number.toString()).padStart(12) +
                    ((denom.Value * denom.Number).toString()).padStart(12)
                ).substring(0, maxLinechar);
                printStringArray.push(line);

            }
            printStringArray.push(' '.repeat(20) + '-'.repeat(20));
            printStringArray.push('Total'.padEnd(16) + (totalQuantity.toString()).padStart(12) + (totalAmount.toString()).padStart(12));
            break;
        }

        case "SBV":
        case "SBV+REJ": {
            printStringArray.push('Machine Serial:  ' + serial);
            printStringArray.push('Type:            ' + counterType);
            printStringArray.push('Start Time:      ' + startTime);

            if (counterType.toUpperCase() === "BPS M5" || counterType.toUpperCase() === "BPS M7") {
                printStringArray.push('Operator:        ' + operatorName);
                printStringArray.push('User ID :        ' + operatorID);
                printStringArray.push('Header Card ID   ' + headCardUnit);
            } else {
                printStringArray.push('Operator:        ' + operatorID);
                printStringArray.push('Deposit ID       ' + depositID);
            }

            printStringArray.push('Declared Amount: ' + declaredAmount);
            printStringArray.push('End Time:        ' + endTime);
            printStringArray.push('-'.repeat(maxLinechar));
            printStringArray.push(formatLine('CURRENCY', defaultCurrency));
            printStringArray.push('QUAL'.padEnd(8) +
                'DENOM'.padEnd(8) +
                'NUMB#'.padStart(12) +
                'AMOUNT'.padStart(12));

            const grouped = {};

            for (const denomination of counters) {
                const currency = defaultCurrency;
                const value = Number(denomination.$.Value ?? denomination.$.value);
                const quality = denomination.$.Quality?.trim() ?? denomination.$.quality;
                const number = Number(denomination.$.Number ?? denomination.$.number);
                const amount = value * number;

                const denomID = denomination.$.DenomID ?? denomination.$.denomid;
                const denomMap = node.context().global.get("denomId") || {};
                const denomMeta = denomMap[denomID];
                const denomName = denomMeta?.name ?? `${defaultCurrency} ${value}`;
                const key = `${denomID}_${quality}`;

                if (!grouped[key]) {
                    grouped[key] = {
                        currency,
                        denomID,
                        denomName,
                        value,
                        quality,
                        number: 0,
                        amount: 0
                    };
                }
                grouped[key].number += number;
                grouped[key].amount += amount;

                totalQuantity += number;
                totalAmount += amount;

                if (quality.toUpperCase() !== "REJECT") {
                    fitTotal += number;
                    fitValue += amount;
                }

                if (/^REJECT$/i.test(quality)) {
                    rejectTotal += number;
                    rejectValue += amount;
                }
            }

            const sorted = Object.values(grouped).sort((a, b) => a.value - b.value);

            for (const item of sorted) {
                const normalizedQuality = item.quality.toUpperCase() === "ACCEPTED" ? "Accept" : item.quality;
                const qual = normalizedQuality.toUpperCase().padEnd(8);
                const denom = `${item.currency} ${item.denomName ? item.denomName.replace('ZAR', "").trim() : item.value}`.replace(/_/g, " ").replace(/ +/g, " ").padEnd(12);
                const num = item.number.toString().padStart(8);
                const amt = item.amount.toString().padStart(12);
                const line = (qual + denom + num + amt).substring(0, maxLinechar);
                if (reportType === "SBV") {
                    if (!item.quality.toUpperCase().includes("REJECT")) {
                        printStringArray.push(line);
                    }
                } else if (reportType === "SBV+Rej") {
                    printStringArray.push(line);
                }
            }

            printStringArray.push('-'.repeat(maxLinechar));
            printStringArray.push('TOTALS');
            printStringArray.push('-'.repeat(maxLinechar));

            printStringArray.push('UNFIT/FIT NOTES:  ' + fitTotal.toString().padStart(12));
            printStringArray.push('UNFIT/FIT AMOUNT: ' + fitValue.toString().padStart(12))
            printStringArray.push('REJECTS:          ' + rejectTotal.toString().padStart(12));
            printStringArray.push('REJECTS AMOUNT:   ' + rejectValue.toString().padStart(12))
            printStringArray.push('TOTAL NOTES:      ' + totalQuantity.toString().padStart(12));
            printStringArray.push('TOTAL AMOUNT:     ' + totalAmount.toString().padStart(12));
            if (Number(declaredAmount) - Number(totalAmount) < 0) {
                printStringArray.push('POSITIVE VARIANCE:' + (Number(totalAmount) - Number(declaredAmount)).toString().padStart(12));
            } else if (Number(declaredAmount) - Number(totalAmount) > 0) {
                const variance = Number(declaredAmount) - Number(totalAmount);
                printStringArray.push('NEGATIVE VARIANCE:' + ("-" + variance).toString().padStart(12));
            } else { }
            printStringArray.push('-'.repeat(maxLinechar));
            if (counterType.toUpperCase() === "BPS M5" || counterType.toUpperCase() === "BPS M7") {
                if (headerUnit?.$?.rejects?.toUpperCase() === "YES") {
                    printStringArray.push('RECONCILER REJECTS: ' + headerUnit?.Counters?.[0]?.Input?.[0]?.TotalInput?.[0]?.$?.Prioritized.padStart(10) ?? (""));
                    printStringArray.push('-'.repeat(maxLinechar));
                } else { }
            } else { }
            break;
        }
        default:
    }

    if (!enabledDevice.toUpperCase().includes('ANALOG')) {
        if (enabledDevice.toUpperCase() === "BOSCH"){
            for (const iterator of printStringArray) {
                node.status({ fill: "green", shape: "ring", text: "IP report geneerated" });
                node.send([{ payload: iterator
                    .replace(/\s+/g, " ")
                    .replace(/\s/g, "_")
                    .replace(/-+/g, '-')
                    .trim() },
                { payload: true }]);
            }
            return null
        }
        for (const iterator of printStringArray) {
            node.status({ fill: "green", shape: "ring", text: "IP report geneerated" });
            node.send([{ payload: iterator },
            { payload: true }]);
        }
        return null;
    } else {
        node.status({ fill: "green", shape: "dot", text: "analogue report generated" });
        node.send([{ payload: printStringArray.toString().replace(/,/g, "\r\n") + "\r\n" },
        { payload: true }])
    }

    function formatLine(label, value = '') {
        const labelStr = label.toString().trim();
        const valueStr = value.toString().trim();
        const dots = ' '.repeat(Math.max(0, maxLinechar - labelStr.length - valueStr.length));
        return (labelStr + dots + valueStr).substring(0, maxLinechar);
    }

    function centerLine(text) {
        const trimmed = text.toString().trim();
        const padded = trimmed.padStart((maxLinechar + trimmed.length) / 2).padEnd(maxLinechar);
        return padded.substring(0, maxLinechar);
    }

    function remapKeys(array, keyMap) {
    return array.map(obj => {
        const newObj = {};
        for (const [oldKey, newKey] of Object.entries(keyMap)) {
        if (obj.hasOwnProperty(oldKey)) {
            newObj[newKey] = obj[oldKey];
        }
        }
        return newObj;
    });
    }
    
};
