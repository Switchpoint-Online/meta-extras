// const usbDetect = require('usb-detection');

// // Start monitoring
// usbDetect.startMonitoring();

// usbDetect.on('add', (device) => {
//   console.log('🔌 USB device plugged in:', device);
// });

// usbDetect.on('remove', (device) => {
//   console.log('❌ USB device removed:', device);
// });

// console.log('🟢 USB detection started. Waiting for events...');

const usbDetect = require('usb-detection');
const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');

const MOUNT_POINT = '/tmp/stick';

// Create mount point if it doesn't exist
if (!fs.existsSync(MOUNT_POINT)) {
  fs.mkdirSync(MOUNT_POINT, { recursive: true });
}

// Start monitoring USB events
usbDetect.startMonitoring();

console.log('🟢 Monitoring USB devices...');

usbDetect.on('add', (device) => {
  console.log(`🔌 USB device connected: VID ${device.vendorId}, PID ${device.productId}`);
  detectAndMountUSB();
});

usbDetect.on('remove', (device) => {
  console.log(`❌ USB device removed: VID ${device.vendorId}, PID ${device.productId}`);
  // Optional: unmount or cleanup if needed
});

function detectAndMountUSB(retries = 5) {
  if (retries === 0) {
    console.warn('⚠️ No USB partitions found after retries.');
    return;
  }

  setTimeout(() => {
    exec('lsblk -J -o NAME,MOUNTPOINT,TRAN,RM,HOTPLUG,FSTYPE', (err, stdout) => {
      if (err) {
        console.error('⚠️ lsblk error:', err.message);
        return;
      }

      try {
        const info = JSON.parse(stdout);
        const devices = info.blockdevices || [];

        // Flatten partition list
        const candidates = devices.flatMap(dev => {
          if (dev.tran === 'usb' && dev.rm && dev.hotplug && dev.children) {
            return dev.children.filter(child =>
              !child.mountpoint &&
              (!child.fstype || ['vfat', 'fat32', 'exfat', 'ntfs'].includes(child.fstype.toLowerCase()))
            );
          }
          return [];
        });

        if (candidates.length === 0) {
          console.log(`🕐 Waiting for partition (retries left: ${retries - 1})`);
          detectAndMountUSB(retries - 1);
          return;
        }

        const partition = candidates[0];
        const devPath = `/dev/${partition.name}`;
        console.log(`📂 Mounting ${devPath} to ${MOUNT_POINT}`);

        exec(`mount ${devPath} ${MOUNT_POINT}`, (err) => {
          if (err) {
            console.error(`❌ Failed to mount ${devPath}:`, err.message);
          } else {
            console.log(`✅ Mounted ${devPath} to ${MOUNT_POINT}`);
            listMountedFiles();
          }
        });

      } catch (e) {
        console.error('❌ Failed to parse lsblk output:', e.message);
      }
    });
  }, 1000); // wait 1s
}

function listMountedFiles() {
  fs.readdir(MOUNT_POINT, (err, files) => {
    if (err) {
      console.error('❌ Could not read mount directory:', err.message);
      return;
    }
    console.log('📁 USB contents:');
    files.forEach(f => console.log(` - ${f}`));
  });
}
